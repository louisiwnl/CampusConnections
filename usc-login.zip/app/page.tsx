import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Shield, User, Key } from "lucide-react"
import Image from "next/image"

export default function LoginPage() {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header with USC Logo */}
      <header className="bg-white py-6 px-8 border-b">
        <div className="flex items-center justify-center">
          <Image
            src="/images/usc-logo.jpg"
            alt="University of San Carlos Logo"
            width={400}
            height={120}
            className="h-20 w-auto"
          />
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-6xl flex gap-8 items-center">
          {/* Login Form */}
          <div className="flex-1 max-w-md">
            <Card className="p-8 border-2 border-gray-300">
              <div className="space-y-6">
                {/* Login Header */}
                <div className="flex items-center gap-3 mb-8">
                  <Shield className="w-8 h-8 text-gray-700" />
                  <h1 className="text-xl font-semibold text-gray-800">Login to your account</h1>
                </div>

                {/* Username Field */}
                <div className="space-y-2">
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <Input
                      type="text"
                      placeholder="Username"
                      className="pl-12 py-3 text-base border-gray-300 rounded-md"
                    />
                  </div>
                </div>

                {/* Password Field */}
                <div className="space-y-2">
                  <div className="relative">
                    <Key className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <Input
                      type="password"
                      placeholder="Password"
                      className="pl-12 py-3 text-base border-gray-300 rounded-md"
                    />
                  </div>
                </div>

                {/* Login Button */}
                <Button className="w-full bg-green-600 hover:bg-green-700 text-white py-3 text-base font-medium rounded-md mt-8">
                  LOGIN
                </Button>

                {/* Copyright */}
                <div className="text-center text-sm text-gray-600 mt-8">
                  2025 © UNIVERSITY OF SAN CARLOS
                  <br />
                  CAMPUS CONNECTIONS
                </div>
              </div>
            </Card>
          </div>

          {/* Dean's Listers Image */}
          <div className="flex-1 max-w-2xl">
            <div className="relative">
              <Image
                src="/images/deans-listers.jpg"
                alt="Dean's Listers for the Bachelors of Science in Computer Engineering"
                width={800}
                height={600}
                className="w-full h-auto rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
