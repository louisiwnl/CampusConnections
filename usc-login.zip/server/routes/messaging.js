const express = require("express")
const { Pool } = require("pg")
const router = express.Router()

// PostgreSQL connection
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
})

// Middleware to verify JWT token
const jwt = require("jsonwebtoken")
const verifyToken = (req, res, next) => {
  const token = req.header("Authorization")?.replace("Bearer ", "")
  if (!token) {
    return res.status(401).json({ message: "Access denied. No token provided." })
  }
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || "usc_campus_connections_secret")
    req.user = decoded
    next()
  } catch (error) {
    res.status(400).json({ message: "Invalid token" })
  }
}

// Send message to adviser
router.post("/send", verifyToken, async (req, res) => {
  try {
    const { recipientId, message, messageType = "advising" } = req.body
    const senderId = req.user.userId

    // Verify that the recipient is the user's assigned adviser (for students)
    if (req.user.role === "student") {
      const adviserQuery = `
        SELECT adviser_id FROM student_advisers 
        WHERE student_id = $1 AND adviser_id = $2 AND active = true
      `
      const adviserResult = await pool.query(adviserQuery, [senderId, recipientId])

      if (adviserResult.rows.length === 0) {
        return res.status(403).json({ message: "You can only message your assigned adviser" })
      }
    }

    // Insert message
    const messageQuery = `
      INSERT INTO messages (sender_id, recipient_id, message, message_type, created_at)
      VALUES ($1, $2, $3, $4, NOW())
      RETURNING *
    `

    const result = await pool.query(messageQuery, [senderId, recipientId, message, messageType])

    res.json({
      message: "Message sent successfully",
      messageData: result.rows[0],
    })
  } catch (error) {
    console.error("Message send error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

// Get conversation between user and another person
router.get("/conversation/:userId", verifyToken, async (req, res) => {
  try {
    const { userId } = req.params
    const currentUserId = req.user.userId

    const conversationQuery = `
      SELECT m.*, 
             s.first_name as sender_first_name, s.last_name as sender_last_name,
             r.first_name as recipient_first_name, r.last_name as recipient_last_name
      FROM messages m
      JOIN users s ON m.sender_id = s.id
      JOIN users r ON m.recipient_id = r.id
      WHERE (m.sender_id = $1 AND m.recipient_id = $2)
         OR (m.sender_id = $2 AND m.recipient_id = $1)
      ORDER BY m.created_at ASC
    `

    const result = await pool.query(conversationQuery, [currentUserId, userId])
    res.json(result.rows)
  } catch (error) {
    console.error("Conversation fetch error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

// Get user's conversations list
router.get("/conversations", verifyToken, async (req, res) => {
  try {
    const userId = req.user.userId

    const conversationsQuery = `
      SELECT DISTINCT 
        CASE 
          WHEN m.sender_id = $1 THEN m.recipient_id 
          ELSE m.sender_id 
        END as other_user_id,
        CASE 
          WHEN m.sender_id = $1 THEN r.first_name 
          ELSE s.first_name 
        END as other_user_first_name,
        CASE 
          WHEN m.sender_id = $1 THEN r.last_name 
          ELSE s.last_name 
        END as other_user_last_name,
        MAX(m.created_at) as last_message_time
      FROM messages m
      JOIN users s ON m.sender_id = s.id
      JOIN users r ON m.recipient_id = r.id
      WHERE m.sender_id = $1 OR m.recipient_id = $1
      GROUP BY other_user_id, other_user_first_name, other_user_last_name
      ORDER BY last_message_time DESC
    `

    const result = await pool.query(conversationsQuery, [userId])
    res.json(result.rows)
  } catch (error) {
    console.error("Conversations fetch error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

module.exports = router
