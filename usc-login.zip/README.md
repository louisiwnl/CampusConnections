# USC Campus Connections

A digital communication platform for student-faculty advisory and consultation at the University of San Carlos, based on the research methodology outlined in the Computer Engineering Department manuscript.

## Technology Stack

- **Frontend**: React.js (JavaScript)
- **Backend**: Node.js with Express
- **Database**: PostgreSQL (with optional Cloud Firestore for real-time messaging)
- **Authentication**: JWT with ISMIS integration
- **AI Integration**: Google Gemini API for consultation summaries

## Features

- **ISMIS Authentication**: Secure login using existing university credentials
- **Subject-based Consultation Booking**: Students can book consultations with faculty teaching their enrolled courses
- **Academic Advising Messaging**: Direct messaging between students and assigned advisers
- **Real-time Notifications**: Status updates for consultation requests
- **AI-powered Summaries**: Automated consultation documentation using Gemini API
- **Monitoring Forms**: Accreditation-ready consultation and advising records

## Installation

### Prerequisites
- Node.js (v16 or higher)
- PostgreSQL database
- ISMIS API access (for authentication)
- Google Gemini API key (for AI summaries)

### Setup

1. **Clone the repository**
   \`\`\`bash
   git clone <your-repo-url>
   cd usc-campus-connections
   \`\`\`

2. **Install dependencies**
   \`\`\`bash
   npm install
   npm run install-client
   \`\`\`

3. **Database Setup**
   - Create a PostgreSQL database
   - Run the schema file: `psql -d your_database < database/schema.sql`

4. **Environment Configuration**
   - Copy `.env.example` to `.env`
   - Fill in your database credentials and API keys

5. **Start the application**
   \`\`\`bash
   npm run dev
   \`\`\`

## Project Structure

\`\`\`
usc-campus-connections/
├── client/                 # React.js frontend
│   ├── src/
│   │   ├── components/     # React components
│   │   └── App.js         # Main app component
├── server/                # Node.js backend
│   ├── routes/            # API routes
│   ├── middleware/        # Authentication middleware
│   └── config/           # Database configuration
├── database/             # SQL schema files
└── public/              # Static assets
\`\`\`

## API Endpoints

### Authentication
- `POST /api/auth/login` - ISMIS login
- `GET /api/auth/profile` - Get user profile

### Consultations
- `GET /api/consultations/slots/:facultyId` - Get available consultation slots
- `POST /api/consultations/book` - Book a consultation
- `GET /api/consultations/my-consultations` - Get user's consultations

### Messaging
- `POST /api/messaging/send` - Send message to adviser
- `GET /api/messaging/conversation/:userId` - Get conversation
- `GET /api/messaging/conversations` - Get conversations list

## Research Alignment

This implementation follows the methodology described in the manuscript:
- **Design and Development Research (DDR)** approach
- **Modified Waterfall SDLC** model
- **Role-based access control** for students, faculty, admin, and superadmin
- **Integration with existing USC systems** (ISMIS, E-Portfolio)
- **Focus on first-year Computer Engineering students** for pilot implementation

## Contributing

This project is developed by the USC Computer Engineering Department as part of academic research. For contributions or issues, please contact the development team.

## License

MIT License - University of San Carlos Computer Engineering Department
