"use client"

import { useState } from "react"

const LoginPage = () => {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")

  const handleLogin = (e) => {
    e.preventDefault()
    // TODO: Implement ISMIS authentication integration
    console.log("Login attempt:", { username, password })
  }

  return (
    <div className="login-container">
      {/* Header with USC Logo */}
      <header className="header">
        <div className="header-content">
          <img src="/images/usc-logo.png" alt="University of San Carlos Logo" className="usc-logo" />
          <div className="university-info">
            <h1 className="university-name">UNIVERSITY of SAN CARLOS</h1>
            <p className="university-motto">SCIENTIA • VIRTUS • DEVOTIO</p>
          </div>
        </div>
      </header>
      {/* Login Form */}
      <form className="login-form" onSubmit={handleLogin}>
        <div className="form-group">
          <label htmlFor="username">Username</label>
          <input type="text" id="username" value={username} onChange={(e) => setUsername(e.target.value)} required />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="login-button">
          Login
        </button>
      </form>
    </div>
  )
}

export default LoginPage
