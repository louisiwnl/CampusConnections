const { Pool } = require("pg")
require("dotenv").config()

// PostgreSQL connection configuration
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
  max: 20, // Maximum number of clients in the pool
  idleTimeoutMillis: 30000, // Close idle clients after 30 seconds
  connectionTimeoutMillis: 2000, // Return an error after 2 seconds if connection could not be established
})

// Test database connection
pool.on("connect", () => {
  console.log("📊 Connected to PostgreSQL database")
})

pool.on("error", (err) => {
  console.error("❌ Unexpected error on idle client", err)
  process.exit(-1)
})

// Function to initialize database tables
const initializeDatabase = async () => {
  try {
    // Check if users table exists
    const result = await pool.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'users'
      );
    `)

    if (!result.rows[0].exists) {
      console.log("🔧 Database tables not found. Please run the schema.sql file to create tables.")
      console.log("📝 You can find the schema in database/schema.sql")
    } else {
      console.log("✅ Database tables are ready")
    }
  } catch (error) {
    console.error("❌ Database initialization error:", error)
  }
}

module.exports = {
  pool,
  initializeDatabase,
}
