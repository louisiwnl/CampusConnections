const express = require("express")
const { Pool } = require("pg")
const router = express.Router()

// PostgreSQL connection
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
})

// Middleware to verify JWT token (imported from auth.js)
const jwt = require("jsonwebtoken")
const verifyToken = (req, res, next) => {
  const token = req.header("Authorization")?.replace("Bearer ", "")
  if (!token) {
    return res.status(401).json({ message: "Access denied. No token provided." })
  }
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || "usc_campus_connections_secret")
    req.user = decoded
    next()
  } catch (error) {
    res.status(400).json({ message: "Invalid token" })
  }
}

// Get available consultation slots for a faculty member
router.get("/slots/:facultyId", verifyToken, async (req, res) => {
  try {
    const { facultyId } = req.params

    // Query faculty consultation schedule based on their load report
    const slotsQuery = `
      SELECT cs.id, cs.date, cs.start_time, cs.end_time, cs.is_available,
             f.first_name, f.last_name, s.subject_code, s.subject_name
      FROM consultation_slots cs
      JOIN users f ON cs.faculty_id = f.id
      JOIN faculty_subjects fs ON f.id = fs.faculty_id
      JOIN subjects s ON fs.subject_id = s.id
      WHERE cs.faculty_id = $1 AND cs.is_available = true
      AND cs.date >= CURRENT_DATE
      ORDER BY cs.date, cs.start_time
    `

    const result = await pool.query(slotsQuery, [facultyId])
    res.json(result.rows)
  } catch (error) {
    console.error("Consultation slots fetch error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

// Book a consultation
router.post("/book", verifyToken, async (req, res) => {
  try {
    const { slotId, subject, description } = req.body
    const studentId = req.user.userId

    // Check if slot is still available
    const slotQuery = "SELECT * FROM consultation_slots WHERE id = $1 AND is_available = true"
    const slotResult = await pool.query(slotQuery, [slotId])

    if (slotResult.rows.length === 0) {
      return res.status(400).json({ message: "Consultation slot not available" })
    }

    // Create consultation booking
    const bookingQuery = `
      INSERT INTO consultations (student_id, faculty_id, slot_id, subject, description, status, created_at)
      VALUES ($1, $2, $3, $4, $5, 'pending', NOW())
      RETURNING *
    `

    const slot = slotResult.rows[0]
    const bookingResult = await pool.query(bookingQuery, [studentId, slot.faculty_id, slotId, subject, description])

    // Mark slot as unavailable
    await pool.query("UPDATE consultation_slots SET is_available = false WHERE id = $1", [slotId])

    res.json({
      message: "Consultation booked successfully",
      consultation: bookingResult.rows[0],
    })
  } catch (error) {
    console.error("Consultation booking error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

// Get user's consultations
router.get("/my-consultations", verifyToken, async (req, res) => {
  try {
    const userId = req.user.userId
    const userRole = req.user.role

    let consultationsQuery
    if (userRole === "student") {
      consultationsQuery = `
        SELECT c.*, cs.date, cs.start_time, cs.end_time,
               f.first_name as faculty_first_name, f.last_name as faculty_last_name
        FROM consultations c
        JOIN consultation_slots cs ON c.slot_id = cs.id
        JOIN users f ON c.faculty_id = f.id
        WHERE c.student_id = $1
        ORDER BY cs.date DESC, cs.start_time DESC
      `
    } else {
      consultationsQuery = `
        SELECT c.*, cs.date, cs.start_time, cs.end_time,
               s.first_name as student_first_name, s.last_name as student_last_name
        FROM consultations c
        JOIN consultation_slots cs ON c.slot_id = cs.id
        JOIN users s ON c.student_id = s.id
        WHERE c.faculty_id = $1
        ORDER BY cs.date DESC, cs.start_time DESC
      `
    }

    const result = await pool.query(consultationsQuery, [userId])
    res.json(result.rows)
  } catch (error) {
    console.error("Consultations fetch error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

module.exports = router
