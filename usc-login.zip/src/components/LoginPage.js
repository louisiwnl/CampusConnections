"use client"

import { useState } from "react"
import "./LoginPage.css"

const LoginPage = () => {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")

  const handleLogin = (e) => {
    e.preventDefault()
    // TODO: Implement ISMIS authentication integration
    console.log("Login attempt:", { username, password })
  }

  return (
    <div className="login-container">
      {/* Header with USC Logo */}
      <header className="header">
        <div className="header-content">
          <img src="/images/usc-logo.jpg" alt="University of San Carlos Logo" className="usc-logo" />
          <div className="university-info">
            <h1 className="university-name">UNIVERSITY of SAN CARLOS</h1>
            <p className="university-motto">SCIENTIA • VIRTUS • DEVOTIO</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="main-content">
        <div className="content-wrapper">
          {/* Login Form */}
          <div className="login-section">
            <div className="login-card">
              <div className="login-header">
                <div className="shield-icon">🛡️</div>
                <h2>Login to your account</h2>
              </div>

              <form onSubmit={handleLogin} className="login-form">
                {/* Username Field */}
                <div className="input-group">
                  <div className="input-wrapper">
                    <span className="input-icon">👤</span>
                    <input
                      type="text"
                      placeholder="Username"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="form-input"
                      required
                    />
                  </div>
                </div>

                {/* Password Field */}
                <div className="input-group">
                  <div className="input-wrapper">
                    <span className="input-icon">🔑</span>
                    <input
                      type="password"
                      placeholder="Password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="form-input"
                      required
                    />
                  </div>
                </div>

                {/* Login Button */}
                <button type="submit" className="login-button">
                  LOGIN
                </button>

                {/* Copyright */}
                <div className="copyright">
                  2025 © UNIVERSITY OF SAN CARLOS
                  <br />
                  CAMPUS CONNECTIONS
                </div>
              </form>
            </div>
          </div>

          {/* Dean's Listers Image */}
          <div className="image-section">
            <div className="image-container">
              <img
                src="/images/deans-listers.jpg"
                alt="Dean's Listers for the Bachelors of Science in Computer Engineering"
                className="deans-listers-image"
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

export default LoginPage
