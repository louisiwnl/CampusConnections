const jwt = require("jsonwebtoken")
const { pool } = require("../config/database")

// Middleware to verify JWT token
const verifyToken = (req, res, next) => {
  const token = req.header("Authorization")?.replace("Bearer ", "")

  if (!token) {
    return res.status(401).json({ message: "Access denied. No token provided." })
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || "usc_campus_connections_secret")
    req.user = decoded
    next()
  } catch (error) {
    res.status(400).json({ message: "Invalid token" })
  }
}

// Middleware to check user role
const requireRole = (roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ message: "Authentication required" })
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ message: "Insufficient permissions" })
    }

    next()
  }
}

// Middleware to verify student-faculty relationship
const verifyStudentFacultyRelation = async (req, res, next) => {
  try {
    const { facultyId } = req.params
    const studentId = req.user.userId

    // Check if student is enrolled in any subject taught by this faculty
    const relationQuery = `
      SELECT fs.faculty_id 
      FROM faculty_subjects fs
      JOIN student_enrollments se ON fs.subject_id = se.subject_id
      WHERE fs.faculty_id = $1 AND se.student_id = $2 AND fs.active = true
    `

    const result = await pool.query(relationQuery, [facultyId, studentId])

    if (result.rows.length === 0) {
      return res.status(403).json({
        message: "You can only book consultations with faculty teaching your enrolled subjects",
      })
    }

    next()
  } catch (error) {
    console.error("Relation verification error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
}

module.exports = {
  verifyToken,
  requireRole,
  verifyStudentFacultyRelation,
}
