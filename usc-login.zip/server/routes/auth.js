const express = require("express")
const bcrypt = require("bcryptjs")
const jwt = require("jsonwebtoken")
const { Pool } = require("pg")
const router = express.Router()

// PostgreSQL connection
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
})

// ISMIS Authentication Integration
// This would integrate with the existing ISMIS system
router.post("/login", async (req, res) => {
  try {
    const { username, password } = req.body

    if (!username || !password) {
      return res.status(400).json({ message: "Username and password are required" })
    }

    // TODO: Integrate with ISMIS database for authentication
    // For now, this is a placeholder implementation

    // Query user from database (would be ISMIS integration)
    const userQuery = `
      SELECT id, username, email, role, first_name, last_name, department
      FROM users 
      WHERE username = $1 AND active = true
    `

    const userResult = await pool.query(userQuery, [username])

    if (userResult.rows.length === 0) {
      return res.status(401).json({ message: "Invalid credentials" })
    }

    const user = userResult.rows[0]

    // TODO: Verify password with ISMIS system
    // const isValidPassword = await bcrypt.compare(password, user.password_hash);
    // For demo purposes, accepting any password
    const isValidPassword = true

    if (!isValidPassword) {
      return res.status(401).json({ message: "Invalid credentials" })
    }

    // Generate JWT token
    const token = jwt.sign(
      {
        userId: user.id,
        username: user.username,
        role: user.role,
        department: user.department,
      },
      process.env.JWT_SECRET || "usc_campus_connections_secret",
      { expiresIn: "24h" },
    )

    res.json({
      message: "Login successful",
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        firstName: user.first_name,
        lastName: user.last_name,
        department: user.department,
      },
    })
  } catch (error) {
    console.error("Login error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

// Verify token middleware
const verifyToken = (req, res, next) => {
  const token = req.header("Authorization")?.replace("Bearer ", "")

  if (!token) {
    return res.status(401).json({ message: "Access denied. No token provided." })
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || "usc_campus_connections_secret")
    req.user = decoded
    next()
  } catch (error) {
    res.status(400).json({ message: "Invalid token" })
  }
}

// Get current user profile
router.get("/profile", verifyToken, async (req, res) => {
  try {
    const userQuery = `
      SELECT id, username, email, role, first_name, last_name, department, created_at
      FROM users 
      WHERE id = $1
    `

    const userResult = await pool.query(userQuery, [req.user.userId])

    if (userResult.rows.length === 0) {
      return res.status(404).json({ message: "User not found" })
    }

    const user = userResult.rows[0]
    res.json({
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      firstName: user.first_name,
      lastName: user.last_name,
      department: user.department,
      createdAt: user.created_at,
    })
  } catch (error) {
    console.error("Profile fetch error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

module.exports = router
